import os
import inspect
from configparser import ConfigParser
import argparse
from cryptography.fernet import Fernet, InvalidToken
import M2Crypto
import base64


class CryptoEngine_M2C:

    def __init__(self, **kwargs):
        """
        Class constructor

        Args:
            crypto_key (str): AES256 simmetric key. If None or not provided, a new key will be generated and stored in self.enckey
        """
        self.enckey = (
            base64.b64decode(kwargs["crypto_key"])
            if "crypto_key" in kwargs and kwargs["crypto_key"]
            else os.urandom(48)
        )
        self.iv = self.enckey[:16]
        self.key = self.enckey[16:]

    def is_encrypted(self, s):
        """
        Checks wether the specified string is encrypted with this backend or not

        Args:
            s (str): String to be tested

        Returns:
            bool: True if encrypted, False otherwise
        """
        try:
            DECRYPT = 0
            cipher = M2Crypto.EVP.Cipher(alg='aes_256_cbc', key=self.key, iv=self.iv, op=DECRYPT)
            plaintext = cipher.update(base64.b64decode(s)) + cipher.final()
        except Exception as e:
            if isinstance(e, M2Crypto.EVP.EVPError):
                return False
        return True

    def encrypt(self, s):
        """
        Encrypts the provided string using the engine instance symmetric key

        Args:
            s (str): String to be encrypted (UTF-8 encoding expected)

        Returns:
            str: Encrypted string (base64 encoded)
        """
        ENCRYPT = 1
        cipher = M2Crypto.EVP.Cipher(alg='aes_256_cbc', key=self.key, iv=self.iv, op=ENCRYPT)
        ciphertext = cipher.update(bytes(s, "utf-8")) + cipher.final()
        return base64.b64encode(ciphertext).decode("utf-8")

    def decrypt(self, s):
        """
        Decrypts the provided string using the engine instance symmetric key

        Args:
            s (str): String to be decrypted (base64 encoding expected)

        Returns:
            str: Decrypted string (UTF-8 encoded)
        """
        DECRYPT = 0
        cipher = M2Crypto.EVP.Cipher(alg='aes_256_cbc', key=self.key, iv=self.iv, op=DECRYPT)
        plaintext = cipher.update(base64.b64decode(s)) + cipher.final()
        return plaintext.decode("utf-8")

    def get_secret(self):
        """
        Gets the engine instance symmetric key

        Returns:
            str: String containing the symmetric key (base64 encoded)
        """
        return base64.b64encode(self.enckey).decode("utf-8")


class CryptoEngine_Fernet:
    """
    Envy CryptoEngine: Fernet
    """

    def __init__(self, **kwargs):
        """
        Class constructor

        Args:
            crypto_key (str): Fernet simmetric key. If None or not provided, a new key will be generated and stored in self.enckey
        """
        self.enckey = (
            bytes(kwargs["crypto_key"], "utf-8")
            if "crypto_key" in kwargs and kwargs["crypto_key"]
            else Fernet.generate_key()
        )
        self.fernet = Fernet(self.enckey)

    def is_encrypted(self, s):
        """
        Checks wether the specified string is encrypted with this backend or not

        Args:
            s (str): String to be tested

        Returns:
            bool: True if encrypted, False otherwise
        """
        try:
            self.fernet.decrypt(bytes(s, "utf-8")).decode("utf-8")
        except Exception as e:
            if isinstance(e, InvalidToken):
                return False
        return True

    def encrypt(self, s):
        """
        Encrypts the provided string using the engine instance symmetric key

        Args:
            s (str): String to be encrypted (UTF-8 encoding expected)

        Returns:
            str: Encrypted string (UTF-8 encoded)
        """
        
        return self.fernet.encrypt(bytes(s, "utf-8")).decode("utf-8")

    def decrypt(self, s):
        """
        Decrypts the provided string using the engine instance symmetric key

        Args:
            s (str): String to be decrypted (UTF-8 encoding expected)

        Returns:
            str: Decrypted string (UTF-8 encoded)
        """
        return self.fernet.decrypt(bytes(s, "utf-8")).decode("utf-8")

    def get_secret(self):
        """
        Gets the engine instance symmetric key

        Returns:
            str: String containing the symmetric key (UTF-8 encoded)
        """
        return self.enckey.decode("utf-8")


class Backend_ConfigParser:
    """
    Envy Storage Backend: INI File/ConfigParser
    """

    def __init__(self, *args, **kwargs):
        """
        Class constructor

        Args:
            envpath (str): Path to environment file. If None or not provided, ".env" is assumed.
        """

        # In case environment file path is not specified, a ".env" file in the same directory as the calling module
        # will be assumed as default. 
        
        f = inspect.currentframe()
        while f.f_globals["__name__"].startswith("envy"):
            f = f.f_back

        self.envfile = (
            kwargs["envpath"]
            if "envpath" in kwargs and kwargs["envpath"]
            #else f"""{os.path.dirname(os.path.abspath(f.f_globals["__file__"]))}/.env"""
            else """./.env"""
        )
        self.cp = ConfigParser(interpolation=None)
        self.cp.read(self.envfile)

    def reload(self):
        """
        Reloads environment file
        """
        self.cp.read(self.envfile)

    def is_multi(self, k, ksect=None):
        """
        Checks whether specified key is multivalued

        Args:
            k (str): Key to be tested
            ksect (str, optional): Key section. Defaults to None (DEFAULT).

        Returns:
            bool: True if key is multivalued, False otherwise
        """
        v = self.cp[ksect if ksect else "DEFAULT"].get(k, None)
        return True if "\n" in v else False

    def multi_serialize(self, lst):
        """
        Serializes a Python list into a string ready to be stored into a Envy key value (backend specific)

        Args:
            lst (list): String to be serialized

        Returns:
            str: Serialized list
        """
        return "\n".join(lst)

    def multi_deserialize(self, v):
        """
        Deserializes a Envy key value into a Python list (backend specific)

        Args:
            v (str): Envy key value to be deserialized

        Returns:
            list: Output list
        """
        return v.split("\n")

    def get_env(self, k, ksect=None, multi=False):
        """
        Gets the specified environment key from backend

        Args:
            k (str): Environment key name
            ksect (str, optional): Environment section where key is located. If None, "DEFAULT" section is used. Defaults to None.

        Returns:
            str: Environment key value (None if not found)
        """
        return self.cp[ksect if ksect else "DEFAULT"].get(k, None)

    def put_env(self, k, v, ksect=None, multi=False):
        """
        Creates/updates the specified environment key in backend.

        Args:
            k (str): Environment key name
            v (str): Environment key value
            ksect (str, optional): Environment section where key is located. If None, "DEFAULT" section is used. Defaults to None.
        """
        safe_ksect = ksect if ksect else "DEFAULT"

        if not safe_ksect in self.cp:
            self.cp[safe_ksect] = {}

        self.cp[safe_ksect][k] = v

        with open(self.envfile, "w") as f:
            self.cp.write(f)


class Envy:
    """
    Envy main class
    """

    # Dictionary with available CryptoEngines.
    # Each entry has a key holding a string id that will be used to refer to it, and a value pointing to the engine implementation class.
    _crypto_engines = {"fernet": CryptoEngine_Fernet, "m2c": CryptoEngine_M2C}

    # Dictionary with available Envy backends.
    # Each entry has a key holding a string id that will be used to refer to it, and a value pointing to the backend implementation class.
    _backends = {"file": Backend_ConfigParser}

    def __init__(self, backend="file", crypto_engine="fernet", **kwargs):
        """
        Class constructor
        Instantiates the Envy class using the specified backend and CryptoEngine.
        Envy encryption secret is expected to be available in 'ENVYK' environment variable.

        Args:
            backend (str, optional): Envy backend id to be used. Defaults to 'file'.
            crypto_engine (str, optional): Envy CryptoEngine to be used. Defaults to 'fernet'.
            **kwargs: Additional arguments to be passed both to the the selected backend and CryptoEngine.
        """
        envy_k = os.getenv("ENVYK")
        if not envy_k:
            print("WARNING: Envy secret not found in environment variables")
        self.backend = self._backends[backend](**kwargs) if backend else None
        self.crypto_engine = self._crypto_engines[crypto_engine](
            crypto_key=envy_k, **kwargs
        )

    @staticmethod
    def find_envy():
        """
        Convenience method to find an Envy instance in the Python call stack, so that a new instance is not
        needed in case there is one already loaded.

        Returns:
            Envy: Found Envy instance, or None if no loaded instance found.
        """
        envy = None
        found = False
        frame = inspect.currentframe()
        m = inspect.getmodule(frame)

        while not found:
            for i in m.__dict__.keys():
                if isinstance(m.__dict__[i], Envy):
                    envy = m.__dict__[i]
                    break

            if envy:
                found = True

            else:
                if m.__name__ == "__main__":
                    break

                frame = frame.f_back
                m = inspect.getmodule(frame)

        return envy

    def _multi_serialize(self, lst):
        """
        Serializes a Python list into a string ready to be stored into a Envy key value using the backend-specific primitives

        Args:
            lst (list): String to be serialized

        Returns:
            str: Serialized list
        """
        return self.backend.multi_serialize(lst)

    def _multi_deserialize(self, v):
        """
        Deserializes a Envy key value into a Python list using the backend-specific primitives

        Args:
            v (str): Envy key value to be deserialized

        Returns:
            list: Output list
        """
        return self.backend.multi_deserialize(v)

    def _decrypt_conditional(self, s):
        """
        Decrypt a string using the configured CryptoEngine if necessary

        Args:
            s (str): String to be decrypted

        Returns:
            str: Cleartext string
        """
        return (
            self.crypto_engine.decrypt(s)
            if s and self.crypto_engine and self.crypto_engine.is_encrypted(s)
            else s
        )

    def _encrypt(self, s):
        """
        Encrypts a string using the configured CryptoEngine

        Args:
            s (str): String to be encrypted

        Returns:
            str: Encrypted string
        """
        return self.crypto_engine.encrypt(s)

    def get_secret(self):
        """
        Gets the Envy encryption secret from current CryptoEngine

        Returns:
            str: Envy encryption secret
        """
        secret = self.crypto_engine.get_secret()
        return secret

    def get_env(self, k, ksect=None, multi=False, crypt=False):
        """
        Gets an Envy environment key value

        Args:
            k (str): Envy key name
            ksect (str, optional): Envy key section. Defaults to None.
            multi (bool, optional): True if key contains a multi-value. Defaults to False.
            crypt (bool, optional): *DEPRECATED* True if the key value needs decryption. Defaults to False

        Returns:
            str|list: Envy key value (string if single-value, list if multi)
        """
        v = self.backend.get_env(k, ksect)
        v = self._decrypt_conditional(v)
        v = self._multi_deserialize(v) if multi else v
        return v

    def put_env(self, k, v, ksect=None, crypt=False):
        """
        Creates/updates an Envy environment key value

        Args:
            k (str): Envy key name to be created
            v (str|list): Envy key value to be stored (string if single-value, list if multi)
            ksect (str, optional): Envy key section. Defaults to None.
            crypt (bool, optional): True if the key value is to be encrypted. Defaults to False.
        """
        stv = self._multi_serialize(v) if isinstance(v, list) else v
        stv = self._encrypt(stv) if crypt and self.crypto_engine else stv
        self.backend.put_env(k, stv, ksect)


"""
Envy comes with a CLI tool that allows for Envy configuration maintenance (Create/Read/Update at this moment)
Please run python envy.py --help for additional information.
"""

def optmgr(opt_list):
    return (
        {opt.split("=")[0]: opt.split("=")[1] for opt in opt_list}
        if opt_list
        else {}
    )

def argmgr():
    parser = argparse.ArgumentParser(
        prog="envy.py",
        description="Envy: An environment/configuration manager for Python",
        epilog="Santander Digital Services 2023",
    )
    parser.add_argument(
        "-b",
        "--backend",
        required=False,
        default="file",
        help='Storage backend id (default is "file")',
    )
    parser.add_argument(
        "-e",
        "--crypto_engine",
        required=False,
        default="fernet",
        help='Crypto engine id (default is "fernet")',
    )
    subparsers = parser.add_subparsers(
        dest="command", help="Envy command to be executed"
    )
    subparsers.required = True
    parser_get = subparsers.add_parser(
        "get", help="Gets the value of an Envy key using specified backend"
    )
    parser_get.add_argument(
        "-o",
        "--option",
    required=False,
    action="append",
        help="Extra options to be passed to Envy backend and crypto engine, in the form -o option1=value1 -o option2=value2...",
    )
    parser_get.add_argument(
        "-s",
        "--keysect",
        required=False,
        help="Key section to retrieve the key from",
    )
    parser_get.add_argument(
        "-m",
        "--multi",
        required=False,
        action="store_true",
        help="If present, handles the retrieved key as multi-valued",
    )
    parser_get.add_argument("key", help="key name to be retrieved")
    parser_put = subparsers.add_parser(
        "put", help="Creates a new Envy key using specified backend"
    )
    parser_put.add_argument(
        "-o",
        "--option",
        required=False,
        action="append",
        help="Extra options to be passed to Envy backend and crypto engine, in the form -o option1=value1 -o option2=value2...",
    )
    parser_put.add_argument(
        "-c",
        "--crypto",
        action="store_true",
        help="If present, use the configured crypto engine for current operation",
    )
    parser_put.add_argument(
        "-s", "--keysect", required=False, help="Key section to store the key into"
    )
    parser_put.add_argument("key", help="key name to be created")
    parser_put.add_argument(
        "value",
        help="key value(s) to be created. If more than one value is specified, a multi-value key will be assumed",
        nargs="*",
    )
    parser_gensecret = subparsers.add_parser(
        "secret",
        help="Gets the current Envy secret fron ENVYK environment variable or generates a new secret on failure",
    )
    argns = parser.parse_args()
    return argns

    
def envy_cli():

    argns = argmgr()

    if argns.command == "secret":
        envy = Envy(backend=None, crypto_engine=argns.crypto_engine)
        print(
            "WARNING: Please make sure the string below is loaded in ENVYK environment variable"
        )
        print(envy.get_secret())

    elif argns.command == "get":
        envy = Envy(
            backend=argns.backend,
            crypto_engine=argns.crypto_engine,
            **optmgr(argns.option),
        )
        print(envy.get_env(k=argns.key, ksect=argns.keysect, multi=argns.multi))

    elif argns.command == "put":
        envy = Envy(
            backend=argns.backend,
            crypto_engine=argns.crypto_engine,
            **optmgr(argns.option),
        )
        envy.put_env(
            k=argns.key, v=argns.value, ksect=argns.keysect, crypt=argns.crypto
        )
